#pragma once

struct arregloDinInt{
    int *ptr;
    int tam;
    int cap;
};
