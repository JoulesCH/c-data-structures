#pragma once
#include <stdio.h>
#include "utils.h"
#include "models.h"


void contarVotosDistrito(struct arregloDinInt * Candidatos, struct arregloDinInt * Cuenta, struct arregloDinInt * Distritos, int no_candidatos){
    struct arregloDinInt candidatos = *Candidatos, cuentas = *Cuenta, distritos = *Distritos;
    printf("\n\nCuenta por distrito:\n");
    for(int i =0; i< distritos.tam; i+=no_candidatos ){             
        printf("\n\n*DISTRITO %d*\n", Get(distritos, i));
        for(int j =0; j<no_candidatos; j++){
            printf("Candidato %d: %d votos\n", j+1, Get(cuentas, i+j) );
        }
    }
}