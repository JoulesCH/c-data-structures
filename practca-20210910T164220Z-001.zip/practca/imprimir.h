#pragma once
#include <stdio.h>
#include "utils.h"

void Menu(){
    printf("\t\t***Sistema de Votos***\n");
    printf("\n1)Ingresar votos\n2)Contar votos\n\n==> ");
}

void imprimirArreglo(struct arregloDinInt arreglo){
    printf("\n");
    for(int i = 0; i<arreglo.tam; i++)
        printf("%d,", Get(arreglo, i));
    printf("\n");
}