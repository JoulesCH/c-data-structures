#pragma once
#include <stdio.h>
#include "utils.h"
#include "models.h"
#include "imprimir.h"

void ingresarVotos(struct arregloDinInt * Candidatos, struct arregloDinInt * Cuenta, struct arregloDinInt * Distritos, int no_candidatos){
    struct arregloDinInt candidatos = *Candidatos, cuenta = *Cuenta, distritos = *Distritos;
    int distrito, j = -1, aux, cuenta_anterior;
    printf("\nIngresa el No. de distrito a capturar: ");

    while((scanf("%d", &distrito) ==1) && distrito != 0){
        j = -1;
        printf("\nRegistrando el distrito %d\n", distrito);
        for(int i = 0; i < distritos.tam; i+=no_candidatos){
            if(Get(distritos, i) == distrito){
                j = i;
                break;
            }
        }
        if(j==-1){
            for(int i =1; i<=no_candidatos; i++){
                printf("Ingresa la cuenta para el candidato %d: ", i);
                scanf("%d", &aux);
                cuenta = Push_Back(cuenta, aux);   
                candidatos = Push_Back(candidatos, i);
                distritos = Push_Back(distritos, distrito);
                imprimirArreglo(cuenta);
            }
        } else{
            for(int i =0; i<no_candidatos; i++){
                printf("Ingresa la cuenta para el candidato %d: ", i+1);
                scanf("%d", &aux);
                cuenta_anterior = Get(cuenta, j + i );
                Insert(&cuenta, aux + cuenta_anterior, j + i);
            }
        }
        printf("\nIngresa el No. de distrito a capturar (0 para salir): ");
    }   
    *Candidatos = candidatos;
    *Cuenta = cuenta;
    *Distritos = distritos;
}