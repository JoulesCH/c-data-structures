#pragma once
#include <stdlib.h>
#include <stdio.h>
// Local headers
#include "models.h"

void Extender_ar(struct arregloDinInt * arr){
    struct arregloDinInt ar = *arr;
    int *p = (int*) malloc((ar.cap*2)* sizeof(int));
    
    for(int n=0; n<ar.cap;n++){
        *(p+n*sizeof(int)) = *(ar.ptr + n *sizeof(int));
    }

    ar.ptr = p;
    ar.cap = 2*ar.cap;

    *arr = ar;

}

void Contraer_ar(struct arregloDinInt * arr){
    struct arregloDinInt ar = *arr;
    int *p = (int*) malloc((ar.cap/2)* sizeof(int));
    
    for(int n=0; n<ar.tam;n++){
        *(p+n*sizeof(int)) = *(ar.ptr + n *sizeof(int));
    }

    ar.ptr = p;
    ar.cap = ar.cap/2;

    *arr = ar;

}

struct arregloDinInt Push_Back(struct arregloDinInt ar, int info){
    if(ar.tam == ar.cap){
        Extender_ar(&ar);
    }
    printf("\ntamanio del arreglo: %d", ar.tam);
    *(ar.ptr + ar.tam * sizeof(int)) = info;
    ar.tam++;
    return ar;
}


void Pop_Back(struct arregloDinInt *arr){
    struct arregloDinInt ar = *arr;
    ar.tam--;
    *(ar.ptr + ar.tam * sizeof(int)) = ' ';
    //Verificar si sobra mucho espacio
    if(ar.tam < ar.cap/2){
        Contraer_ar(&ar);
    }
    *arr = ar;
    
}

void Push_Front(struct arregloDinInt * arr, int info){
    struct arregloDinInt ar = *arr;
    if(ar.tam == ar.cap){
        Extender_ar(&ar);
    }
    for(int n=ar.tam; n> 0 ;n--){
        *(ar.ptr + n * sizeof(int)) = *(ar.ptr + (n-1) * sizeof(int));
    }

    *ar.ptr = info;
    ar.tam++;
    *arr = ar;

}
void Pop_Front(struct arregloDinInt * arr){
    struct arregloDinInt ar = *arr;
    for(int n=0; n< ar.tam ;n++){
        *(ar.ptr + n * sizeof(int)) = *(ar.ptr + (n+1) * sizeof(int));
    }
    ar.tam--;
    //ar.ptr = ar.ptr + sizeof(int);
    

    if(ar.tam < ar.cap/2){
        Contraer_ar(&ar);
    }
    *arr = ar;
}

void Insert(struct arregloDinInt* arr, int info, int pos){
    struct arregloDinInt ar = *arr;
    if(ar.tam == ar.cap){
        Extender_ar(&ar);
    }

    for(int n=ar.tam; n> pos ;n--){
        *(ar.ptr + n * sizeof(int)) = *(ar.ptr + (n-1) * sizeof(int));
    }

    *(ar.ptr + pos * sizeof(int)) = info;
    ar.tam ++;
    *arr = ar;

}
void Remove(struct arregloDinInt *arr, int pos){
    struct arregloDinInt ar = *arr;
    for(int n=pos; n< ar.tam ;n++){
        *(ar.ptr + n * sizeof(int)) = *(ar.ptr + (n+1) * sizeof(int));
    }

    ar.tam--;
    if(ar.tam < ar.cap/2){
        Contraer_ar(&ar);
    }
    *arr = ar;
}
void Set(struct arregloDinInt *arr, int info, int pos){
    struct arregloDinInt ar = *arr;
    *(ar.ptr + pos* sizeof(int)) = info;
    *arr = ar;
}
int Get(struct arregloDinInt ar, int pos){
    return *(ar.ptr + pos*sizeof(int));
}