#include <stdio.h>
#include "models.h"
#include "imprimir.h"
#include "contar.h"
#include "ingreso.h"
#define NO_CANDIDATOS 4

int main(){
    struct arregloDinInt Candidatos = {NULL, 0, NO_CANDIDATOS+1}, Cuenta = {NULL, 0, NO_CANDIDATOS+1}, Distritos = {NULL, 0, NO_CANDIDATOS+1};
    Candidatos.ptr = (int*) malloc((NO_CANDIDATOS+1)*sizeof(int));
    Cuenta.ptr = (int*) malloc((NO_CANDIDATOS+1)*sizeof(int));
    Distritos.ptr = (int*) malloc((NO_CANDIDATOS+1)*sizeof(int));
    int res;
    Menu();
    while((scanf("%d", &res) ==1) && (res == 1 || res == 2)){
        if(res == 1){
            ingresarVotos(&Candidatos, &Cuenta, &Distritos, NO_CANDIDATOS);
            imprimirArreglo(Candidatos);
            imprimirArreglo(Cuenta);
            imprimirArreglo(Distritos);
        } else if(res == 2){
            contarVotosDistrito(&Candidatos, &Cuenta, &Distritos, NO_CANDIDATOS);
        }

        Menu();

    }

    return 0;
}